<?php
	include("functions/check.php");
	/*include("functions/dashboard_function.php");*/
	
	
?>

<?php
$sql =  "SELECT * FROM movies";



if ($_GET['sort'] == 'mname')
{
    $result .= " ORDER BY mname";
}
elseif ($_GET['sort'] == 'myear')
{
    $result .= " ORDER BY myear";
}
elseif ($_GET['sort'] == 'recorded')
{
    $result .= " ORDER BY DateRecorded";
}
elseif($_GET['sort'] == 'added')
{
    $result .= " ORDER BY DateAdded";
}
$result = mysqli_query($db, $sql);
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>movieDB | Home</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

	</head>
	<body class="bg">
		<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Project name</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="dashboard.php">Dashboard</a></li>
			<li><a href="movie.php">Filme</a></li>
			<li><a href="shows.php">Serien</a></li>
			<li><a href="doc.php">Dokumentation</a></li>
			<li><a href="about.php">Über</a></li>
			</ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <i class="fa fa-user-circle" aria-hidden="true"></i>&nbsp;Hi' <?php echo $login_user;?>!&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="functions/logout.php""><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;Ausloggen</a></li>
				<li><a href="profile.php"><i class="fa fa-address-card-o" aria-hidden="true"></i>&nbsp;Profil</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
	
		<div class="container">
	<div class="jumbotron jumbotron-fluid">
		<table class="table table-striped table-hover">
		
		
		
<?php 
		echo "<tr><th>Filmname</th><th>Erscheinungsjahr</th><th>FSK</th><th>IMDB Bewertung</th><th>Genre</th><th>Genre</th><th>Filmlänge</th></tr>";
		if($result === FALSE) { 
    yourErrorHandler(mysqli_error($mysqli));
}
else {
    foreach( $result as $row ) {
		$mname = $row['mname'];
		$myear = $row['myear'];
		$musk = $row['musk'];
		$mrate = $row['mrate'];
		$mgenre1 = $row['mgenre1'];
		$mgenre2 = $row['mgenre2'];
		$mlenge = $row['mlenge'];
		echo "<tr><td style='width: 200px;'>".$mname."</td><td>".$myear."</td><td>".$musk."</td><td>".$mrate."</td><td>".$mgenre1."</td><td>".$mgenre2."</td><td>".$mlenge."</td></tr>";
	}
	echo '<tr>';
		}
	?>
	
	
		
	
	<th><a href="dashboard.php?sort=mname">Filmname:</a></th>	
	<th><a href="dashboard.php?sort=myear">year:</a></th>	
		</table>

			<h1 class="hello">Hallo, <em><?php echo $login_user;?>!</em></h1>
			<a href="functions/logout.php" style="font-size:18px">Logout?</a>
			</div>
		</div>
		
	</body>
</html>
