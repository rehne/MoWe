-- View: Mitarbeiter mit bedienten Kunden

DROP VIEW IF EXISTS v_bedient;

CREATE VIEW v_bedient AS
SELECT a.A_id, m.M_id, m.Vorname AS M_Vorname, m.Nachname AS M_Nachname, k.Vorname AS K_Vorname, k.Nachname AS K_Nachname, a.Ausgeliehen_am
FROM Mitarbeiter m, Kunde k, Auftrag a
WHERE m.M_id = a.M_id
AND k.K_id = a.K_id;



-- Trigger: Ausleihdatum automatisch setzen

DROP TRIGGER IF EXISTS t_ausleihdatum;

CREATE TRIGGER t_ausleihdatum
BEFORE INSERT ON Auftrag
FOR EACH ROW
SET NEW.Ausgeliehen_am = CURDATE();



-- Trigger: Niedrigste Permission für neuen Mitarbeiter vergeben

DROP TRIGGER IF EXISTS t_mitarbeiter;

CREATE TRIGGER t_mitarbeiter
BEFORE INSERT ON Mitarbeiter
FOR EACH ROW
SET NEW.Permission = 1;



-- Procedure: Kunden über der Ausleihfrist

DROP PROCEDURE IF EXISTS p_ausleihfrist;

delimiter //
CREATE PROCEDURE p_ausleihfrist () 
BEGIN
	DECLARE done INT DEFAULT FALSE;
	DECLARE a_id INT;
	DECLARE k_id INT;
	DECLARE k_vorname VARCHAR(30);
	DECLARE k_nachname VARCHAR(30);
	DECLARE a_datum DATE;
	DECLARE a_erledigt DATE;
	DECLARE d_dauer INT;
	DECLARE frist DATE;
	DECLARE crs CURSOR FOR 
		SELECT a.A_id, k.K_id, k.Vorname, k.Nachname, a.Ausgeliehen_am, a.Erledigt, d.Ausleihdauer
		FROM Kunde k, Auftrag a, Dauer d
		WHERE k.K_id = a.K_id AND d.D_id = a.D_id
		ORDER BY a.Ausgeliehen_am;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

	OPEN crs;
	loop1 : LOOP
		FETCH crs INTO a_id, k_id, k_vorname, k_nachname, a_datum, a_erledigt, d_dauer;
		IF done THEN
			LEAVE loop1;
		END IF;
		SET frist = DATE_ADD(a_datum, INTERVAL d_dauer DAY);
		IF CURDATE() > frist AND a_erledigt IS NULL THEN
			SELECT a_id, k_id, k_vorname, k_nachname, a_datum, d_dauer;
		END IF;
	END LOOP loop1;
	CLOSE crs;
END;
//
delimiter ;



-- Function: Beliebtester Film des letzten Monats

DROP FUNCTION IF EXISTS f_monat;

delimiter //
CREATE FUNCTION f_monat () 
	RETURNS BIGINT
BEGIN
	DECLARE f_ean BIGINT;
	DECLARE crs CURSOR FOR 
		SELECT ap.EAN
		FROM Auftragsposten ap, Auftrag a
		WHERE ap.A_id = a.A_id AND MONTH(a.Ausgeliehen_am) = MONTH(DATE_ADD(CURDATE(), INTERVAL -1 MONTH))
		GROUP BY ap.EAN
		ORDER BY COUNT(ap.EAN)
		DESC
		LIMIT 1;

	OPEN crs;
	FETCH crs INTO f_ean;
	CLOSE crs;
	RETURN f_ean;
END;
//
delimiter ;



-- Function: Ausgabe aller Auftragsposten im übergebenem Jahr

DROP FUNCTION IF EXISTS f_ap_anzahl;

delimiter //
CREATE FUNCTION f_ap_anzahl (jahr int) 
	RETURNS INT
BEGIN
	DECLARE anzahl INT;
	DECLARE crs CURSOR FOR 
		SELECT Count(ap.EAN)
		FROM Auftragsposten ap, Auftrag a
		WHERE ap.A_id = a.A_id AND YEAR(a.Ausgeliehen_am) = jahr;

	OPEN crs;
	FETCH crs INTO anzahl;
	CLOSE crs;
	RETURN anzahl;
END;
//
delimiter ;