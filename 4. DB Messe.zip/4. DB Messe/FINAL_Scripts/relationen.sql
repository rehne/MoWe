--
-- Datenbank: `phpmyadmin`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pma_relation`
--

CREATE TABLE IF NOT EXISTS `phpmyadmin`.`pma_relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  KEY `foreign_field` (`foreign_db`,`foreign_table`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

--
-- Daten für Tabelle `pma_relation`
--

INSERT INTO `phpmyadmin`.`pma_relation` (`master_db`, `master_table`, `master_field`, `foreign_db`, `foreign_table`, `foreign_field`) VALUES
('film', 'auftrag', 'K_id', 'film', 'kunde', 'K_id'),
('film', 'auftrag', 'M_id', 'film', 'mitarbeiter', 'M_id'),
('film', 'auftrag', 'D_id', 'film', 'dauer', 'D_id'),
('film', 'auftragsposten', 'A_id', 'film', 'auftrag', 'A_id'),
('film', 'auftragsposten', 'EAN', 'film', 'film', 'EAN'),
('film', 'hat_genre', 'EAN', 'film', 'film', 'EAN'),
('film', 'hat_genre', 'G_id', 'film', 'genre', 'G_id'),
('film', 'hat_hauptdarsteller', 'EAN', 'film', 'film', 'EAN'),
('film', 'hat_hauptdarsteller', 'H_id', 'film', 'hauptdarsteller', 'H_id'),
('film', 'hat_regisseur', 'EAN', 'film', 'film', 'EAN'),
('film', 'hat_regisseur', 'R_id', 'film', 'regisseur', 'R_id');