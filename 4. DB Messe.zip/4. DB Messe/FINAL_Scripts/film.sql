--
-- Datenbank: `film`
--
DROP DATABASE IF EXISTS `film`;
CREATE DATABASE IF NOT EXISTS `film` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `film`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Auftrag`
--

DROP TABLE IF EXISTS `Auftrag`;
CREATE TABLE IF NOT EXISTS `Auftrag` (
  `A_id` int(11) NOT NULL AUTO_INCREMENT,
  `K_id` int(11) NOT NULL,
  `M_id` int(11) NOT NULL,
  `D_id` int(11) NOT NULL,
  `Ausgeliehen_am` date DEFAULT NULL,
  `Erledigt` date DEFAULT NULL,
  PRIMARY KEY (`A_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- RELATIONEN DER TABELLE `Auftrag`:
--   `D_id`
--       `Dauer` -> `D_id`
--   `K_id`
--       `Kunde` -> `K_id`
--   `M_id`
--       `Mitarbeiter` -> `M_id`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Auftragsposten`
--

DROP TABLE IF EXISTS `Auftragsposten`;
CREATE TABLE IF NOT EXISTS `Auftragsposten` (
  `A_id` int(11) NOT NULL,
  `EAN` bigint(13) NOT NULL,
  PRIMARY KEY (`A_id`,`EAN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONEN DER TABELLE `Auftragsposten`:
--   `A_id`
--       `Auftrag` -> `A_id`
--   `EAN`
--       `Film` -> `EAN`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Dauer`
--

DROP TABLE IF EXISTS `Dauer`;
CREATE TABLE IF NOT EXISTS `Dauer` (
  `D_id` int(11) NOT NULL AUTO_INCREMENT,
  `Ausleihdauer` int(2) NOT NULL,
  PRIMARY KEY (`D_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `Dauer`
--

INSERT INTO `Dauer` (`D_id`, `Ausleihdauer`) VALUES
(1, 7),
(2, 14);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Film`
--

DROP TABLE IF EXISTS `Film`;
CREATE TABLE IF NOT EXISTS `Film` (
  `EAN` bigint(13) NOT NULL,
  `Titel` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Bestand` int(11) NOT NULL,
  `Aktueller_Bestand` int(11) NOT NULL,
  `Erscheinungsjahr` int(4) NOT NULL,
  `Gebuehr` float NOT NULL,
  `FSK` int(2) NOT NULL,
  PRIMARY KEY (`EAN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Genre`
--

DROP TABLE IF EXISTS `Genre`;
CREATE TABLE IF NOT EXISTS `Genre` (
  `G_id` int(11) NOT NULL AUTO_INCREMENT,
  `Bezeichnung` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`G_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Daten für Tabelle `Genre`
--

INSERT INTO `Genre` (`G_id`, `Bezeichnung`) VALUES
(1, 'Abenteuer'),
(2, 'Action'),
(3, 'Drama'),
(4, 'Erotik'),
(5, 'Fantasy'),
(6, 'Biografie'),
(7, 'Komödie'),
(8, 'Horror'),
(9, 'Krieg'),
(10, 'Krimi'),
(11, 'Liebe'),
(12, 'Martial-Arts'),
(13, 'Musik'),
(14, 'Science-Fiction'),
(15, 'Sport'),
(16, 'Thriller'),
(17, 'Western');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hat_Genre`
--

DROP TABLE IF EXISTS `hat_Genre`;
CREATE TABLE IF NOT EXISTS `hat_Genre` (
  `EAN` bigint(13) NOT NULL,
  `G_id` int(11) NOT NULL,
  PRIMARY KEY (`EAN`,`G_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONEN DER TABELLE `hat_Genre`:
--   `EAN`
--       `Film` -> `EAN`
--   `G_id`
--       `Genre` -> `G_id`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hat_Hauptdarsteller`
--

DROP TABLE IF EXISTS `hat_Hauptdarsteller`;
CREATE TABLE IF NOT EXISTS `hat_Hauptdarsteller` (
  `EAN` bigint(13) NOT NULL,
  `H_id` int(11) NOT NULL,
  PRIMARY KEY (`EAN`,`H_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONEN DER TABELLE `hat_Hauptdarsteller`:
--   `EAN`
--       `Film` -> `EAN`
--   `H_id`
--       `Hauptdarsteller` -> `H_id`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hat_Regisseur`
--

DROP TABLE IF EXISTS `hat_Regisseur`;
CREATE TABLE IF NOT EXISTS `hat_Regisseur` (
  `EAN` bigint(13) NOT NULL,
  `R_id` int(11) NOT NULL,
  PRIMARY KEY (`EAN`,`R_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONEN DER TABELLE `hat_Regisseur`:
--   `EAN`
--       `Film` -> `EAN`
--   `R_id`
--       `Regisseur` -> `R_id`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Hauptdarsteller`
--

DROP TABLE IF EXISTS `Hauptdarsteller`;
CREATE TABLE IF NOT EXISTS `Hauptdarsteller` (
  `H_id` int(11) NOT NULL AUTO_INCREMENT,
  `Vorname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Nachname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`H_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Kunde`
--

DROP TABLE IF EXISTS `Kunde`;
CREATE TABLE IF NOT EXISTS `Kunde` (
  `K_id` int(11) NOT NULL AUTO_INCREMENT,
  `Vorname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Nachname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Geburtsdatum` date NOT NULL,
  `PLZ` int(5) NOT NULL,
  `Ort` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Strasse` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Hausnummer` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `IBAN` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `Gesperrt` tinyint(1) NOT NULL,
  PRIMARY KEY (`K_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Mitarbeiter`
--

DROP TABLE IF EXISTS `Mitarbeiter`;
CREATE TABLE IF NOT EXISTS `Mitarbeiter` (
  `M_id` int(11) NOT NULL AUTO_INCREMENT,
  `Vorname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Nachname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Benutzername` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Passwort` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Permission` int(1) DEFAULT NULL,
  PRIMARY KEY (`M_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `Mitarbeiter`
--

INSERT INTO `Mitarbeiter` (`M_id`, `Vorname`, `Nachname`, `Benutzername`, `Passwort`, `Permission`) VALUES
(1, 'Admin', 'Admin', 'Admin1', '123', 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Regisseur`
--

DROP TABLE IF EXISTS `Regisseur`;
CREATE TABLE IF NOT EXISTS `Regisseur` (
  `R_id` int(11) NOT NULL AUTO_INCREMENT,
  `Vorname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Nachname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`R_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;